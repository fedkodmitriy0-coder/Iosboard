package com.example.iosboard

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("kb", Context.MODE_PRIVATE)
    fun radius(c: Context) = sp(c).getInt("radius", 8)          // dp, 0..23
    fun side(c: Context) = sp(c).getInt("side", 3)              // dp, 0..32
    fun bottom(c: Context) = sp(c).getInt("bottom", 4)          // dp, 0..48
    fun emojiBelow(c: Context) = sp(c).getBoolean("emojiBelow", true)
    fun theme(c: Context) = sp(c).getInt("theme", 0)            // 0 auto, 1 light, 2 dark
    fun hints(c: Context) = sp(c).getBoolean("hints", true)     // symbols popup on long press
    fun longMs(c: Context) = sp(c).getInt("longMs", 350)        // ms, 150..800
    fun cornerHints(c: Context) = sp(c).getBoolean("cornerHints", true) // small hint symbol on keys
    fun sound(c: Context) = sp(c).getBoolean("sound", true)             // system key click sound
    fun keyH(c: Context) = sp(c).getInt("keyH", 46)             // key height, dp
    fun keyW(c: Context) = sp(c).getInt("keyW", 100)            // key width, % of its cell
    fun volume(c: Context) = sp(c).getInt("volume", 0)          // 0 = system default, else 1..100 %
    fun distinct(c: Context) = sp(c).getBoolean("distinct", true) // separate sounds for space/delete/enter
    fun customOn(c: Context) = sp(c).getBoolean("customOn", true)
    fun custom(c: Context) = sp(c).getString("custom", "") ?: ""
    fun setStr(c: Context, key: String, v: String) = sp(c).edit().putString(key, v).apply()
    fun gapX(c: Context) = sp(c).getInt("gapX", 6)              // gap between keys in a row, dp
    fun gapY(c: Context) = sp(c).getInt("gapY", 11)             // gap between rows, dp
    fun stretch(c: Context) = sp(c).getBoolean("stretch", true)  // stretch middle letter row to the edges
    fun symL(c: Context) = sp(c).getString("symL", ",") ?: ","  // key left of space ("" = none)
    fun symR(c: Context) = sp(c).getString("symR", ".") ?: "."  // key right of space ("" = none)
    fun numRow(c: Context) = sp(c).getBoolean("numRow", false)  // extra row of digits
    fun editorBar(c: Context) = sp(c).getBoolean("editorBar", true)
    fun suggest(c: Context) = sp(c).getBoolean("suggest", true)
    fun autocorrect(c: Context) = sp(c).getBoolean("autocorrect", true)
    fun clipHistory(c: Context) = sp(c).getBoolean("clipHistory", true)
    fun emojiPos(c: Context) = sp(c).getInt("emojiPos", if (sp(c).getBoolean("emojiBelow", true)) 0 else 1) // 0 below, 1 bottom row, 2 only in the panel
    fun langMode(c: Context) = sp(c).getInt("langMode", 0)      // 0 globe button, 1 swipe on space
    fun panel(c: Context) = sp(c).getBoolean("panel", true)     // 4-squares panel under the editor toolbar
    private val CKEYS = arrayOf("cBg", "cKey", "cSpace", "cSpec", "cText")
    fun customColors(c: Context): IntArray {
        val d = Palette.builtIn(1, false)
        return IntArray(5) { sp(c).getInt(CKEYS[it], d[it]) }
    }
    fun setCustom(c: Context, pal: IntArray) {
        val e = sp(c).edit()
        for (i in 0 until 5) e.putInt(CKEYS[i], pal[i])
        e.apply()
    }
    fun accent(c: Context) = sp(c).getInt("cAccent", 0)         // 0 = automatic app colour
    fun bubbleW(c: Context) = sp(c).getInt("bubbleW", 130)       // key preview bubble width, % of the key
    fun bubble(c: Context) = sp(c).getInt("cBubble", 0)          // bubble colour, 0 = automatic
    fun delW(c: Context) = sp(c).getInt("delW", 100)             // Backspace width, % of default
    fun bubbleStem(c: Context) = sp(c).getBoolean("bubbleStem", true)   // stem under the key bubble
    fun bubbleRound(c: Context) = sp(c).getInt("bubbleRound", 25)       // 0 square .. 50 fully round
    fun bubbleH(c: Context) = sp(c).getInt("bubbleH", 54)               // bubble height, dp
    fun bubbleTs(c: Context) = sp(c).getInt("bubbleTs", 36)             // letter size in the bubble, sp
    fun vibOn(c: Context) = sp(c).getBoolean("vibOn", true)
    fun vibMode(c: Context) = sp(c).getInt("vibMode", 0)                // 0 click, 1 tick, 2 strong, 3 custom
    fun vibStrong(c: Context) = sp(c).getBoolean("vibStrong", true)     // stronger on Shift/Enter/Space
    fun vibRelease(c: Context) = sp(c).getBoolean("vibRelease", false)  // buzz on release instead of press
    fun vibMs(c: Context) = sp(c).getInt("vibMs", 12)
    fun vibAmp(c: Context) = sp(c).getInt("vibAmp", 160)
    fun set(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
    fun set(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
}
