package com.example.iosboard

import android.content.Context
import org.json.JSONArray

/** Small local clipboard history (kept in the app's private storage, max 20 items). */
object ClipStore {
    private const val MAX = 20
    private fun sp(c: Context) = c.getSharedPreferences("clips", Context.MODE_PRIVATE)

    fun list(c: Context): List<String> {
        val raw = sp(c).getString("items", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(c: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty() || t.length > 2000) return
        val l = ArrayList(list(c))
        l.remove(t)
        l.add(0, t)
        while (l.size > MAX) l.removeAt(l.size - 1)
        sp(c).edit().putString("items", JSONArray(l).toString()).apply()
    }

    fun clear(c: Context) {
        sp(c).edit().remove("items").apply()
    }
}
