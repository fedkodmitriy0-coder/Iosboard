package com.example.iosboard

import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Colour picker: preview, HEX field, hue / saturation / brightness sliders, swatches, Auto / Cancel / Done. */
class ColorPicker(
    private val ctx: Context,
    private val title: String,
    initial: Int,
    private val allowAuto: Boolean,
    private val onResult: (Int?) -> Unit
) {
    private val dp = ctx.resources.displayMetrics.density
    private val hsv = FloatArray(3)
    private var typing = false
    private lateinit var badge: Badge
    private lateinit var hueS: GradSlider
    private lateinit var satS: GradSlider
    private lateinit var valS: GradSlider
    private lateinit var hex: EditText

    init {
        Color.colorToHSV(initial, hsv)
    }

    private class Badge(ctx: Context) : View(ctx) {
        var color = Color.GRAY
        var textColor = Color.WHITE
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        override fun onDraw(c: Canvas) {
            val d = resources.displayMetrics.density
            val cx = width / 2f
            val cy = height / 2f
            val r = minOf(width, height) / 2f - 4 * d
            path.reset()
            val n = 120
            for (i in 0..n) {
                val a = 2.0 * Math.PI * i / n
                val rr = r + 3 * d * Math.cos(12 * a).toFloat()
                val x = cx + (rr * Math.cos(a)).toFloat()
                val y = cy + (rr * Math.sin(a)).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            p.style = Paint.Style.FILL
            p.color = color
            c.drawPath(path, p)
            p.color = textColor
            p.textAlign = Paint.Align.CENTER
            p.textSize = 26 * d
            p.isFakeBoldText = true
            c.drawText("Aa", cx, cy - (p.descent() + p.ascent()) / 2, p)
        }
    }

    private class GradSlider(ctx: Context, val onChange: (Float) -> Unit) : View(ctx) {
        var value = 0f
        var colors = intArrayOf(Color.BLACK, Color.WHITE)
        var thumbColor = Color.WHITE
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val d = resources.displayMetrics.density

        override fun onMeasure(w: Int, h: Int) {
            setMeasuredDimension(MeasureSpec.getSize(w), (44 * d).toInt())
        }

        override fun onDraw(c: Canvas) {
            val h = 34 * d
            val top = (height - h) / 2
            val r = h / 2
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, colors, null, Shader.TileMode.CLAMP)
            c.drawRoundRect(0f, top, width.toFloat(), top + h, r, r, p)
            p.shader = null
            val cx = r + value * (width - 2 * r)
            val cy = height / 2f
            p.color = Color.WHITE
            c.drawCircle(cx, cy, 15 * d, p)
            p.color = thumbColor
            c.drawCircle(cx, cy, 10 * d, p)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            parent?.requestDisallowInterceptTouchEvent(true)
            val r = 17 * d
            value = ((e.x - r) / (width - 2 * r)).coerceIn(0f, 1f)
            onChange(value)
            invalidate()
            return true
        }
    }

    private fun lum(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    private fun refresh(updateHex: Boolean = true) {
        val h = hsv[0]
        val s = hsv[1]
        val v = hsv[2]
        val color = Color.HSVToColor(floatArrayOf(h, s, v))
        badge.color = color
        badge.textColor = if (lum(color) > 0.6f) Color.BLACK else Color.WHITE
        badge.invalidate()
        hueS.colors = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        hueS.value = h / 360f
        hueS.thumbColor = Color.HSVToColor(floatArrayOf(h, 1f, 1f))
        satS.colors = intArrayOf(Color.HSVToColor(floatArrayOf(h, 0f, v)), Color.HSVToColor(floatArrayOf(h, 1f, v)))
        satS.value = s
        satS.thumbColor = color
        valS.colors = intArrayOf(Color.BLACK, Color.HSVToColor(floatArrayOf(h, s, 1f)))
        valS.value = v
        valS.thumbColor = color
        hueS.invalidate()
        satS.invalidate()
        valS.invalidate()
        if (updateHex) {
            typing = true
            hex.setText(String.format("%06X", color and 0xFFFFFF))
            typing = false
        }
    }

    private fun oval(c: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(c)
        return g
    }

    private fun txt(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, android.graphics.Typeface.BOLD)
        return v
    }

    fun show() {
        val dlg = Dialog(ctx)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pad = (24 * dp).toInt()
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, (16 * dp).toInt())
        val bg = GradientDrawable()
        bg.setColor(0xFF26242E.toInt())
        bg.cornerRadius = 28 * dp
        root.background = bg

        root.addView(txt(title, 26f, bold = true))

        val top = LinearLayout(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(0, (12 * dp).toInt(), 0, (12 * dp).toInt())
        badge = Badge(ctx)
        top.addView(badge, LinearLayout.LayoutParams((84 * dp).toInt(), (84 * dp).toInt()))
        val hexBox = LinearLayout(ctx)
        hexBox.gravity = Gravity.CENTER_VERTICAL
        hexBox.setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), 0)
        val stroke = GradientDrawable()
        stroke.setColor(Color.TRANSPARENT)
        stroke.setStroke((1.5f * dp).toInt(), 0xFF8E8A9B.toInt())
        stroke.cornerRadius = 20 * dp
        hexBox.background = stroke
        hexBox.addView(txt("#", 20f))
        hex = EditText(ctx)
        hex.setTextColor(Color.WHITE)
        hex.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        hex.background = null
        hex.setSingleLine()
        hex.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        hex.filters = arrayOf(InputFilter.LengthFilter(6), InputFilter.AllCaps())
        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (typing) return
                val t = s?.toString() ?: return
                if (t.length == 6) {
                    try {
                        Color.colorToHSV(Color.parseColor("#$t"), hsv)
                        refresh(false)
                    } catch (e: Exception) {
                    }
                }
            }
        })
        hexBox.addView(hex, LinearLayout.LayoutParams(-1, (56 * dp).toInt()))
        val lp = LinearLayout.LayoutParams(0, (60 * dp).toInt(), 1f)
        lp.leftMargin = (16 * dp).toInt()
        top.addView(hexBox, lp)
        root.addView(top)

        hueS = GradSlider(ctx) { v -> hsv[0] = v * 360f; refresh() }
        satS = GradSlider(ctx) { v -> hsv[1] = v; refresh() }
        valS = GradSlider(ctx) { v -> hsv[2] = v; refresh() }
        root.addView(txt("Оттенок", 18f, bold = true))
        root.addView(hueS)
        root.addView(txt("Насыщенность", 18f, bold = true))
        root.addView(satS)
        root.addView(txt("Яркость", 18f, bold = true))
        root.addView(valS)

        val sw = intArrayOf(
            0xFF6750A4.toInt(), 0xFF8E4FC0.toInt(), 0xFFA23E8C.toInt(), 0xFFC2405E.toInt(), 0xFFD9534F.toInt(), 0xFFE87433.toInt(),
            0xFFF0A23A.toInt(), 0xFFDDB840.toInt(), 0xFF9AC25B.toInt(), 0xFF58A66E.toInt(), 0xFF3FA796.toInt(), 0xFF42A0C0.toInt(),
            0xFF3D8BFF.toInt(), 0xFF3F5FD6.toInt(), 0xFF5B5BD6.toInt(), 0xFF7A5848.toInt(), 0xFF607D8B.toInt(), 0xFF222222.toInt()
        )
        val grid = LinearLayout(ctx)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
        for (r in 0 until 3) {
            val row = LinearLayout(ctx)
            for (c in 0 until 6) {
                val color = sw[r * 6 + c]
                val cell = FrameLayout(ctx)
                val dot = View(ctx)
                dot.background = oval(color)
                cell.addView(dot, FrameLayout.LayoutParams((42 * dp).toInt(), (42 * dp).toInt(), Gravity.CENTER))
                cell.setOnClickListener {
                    Color.colorToHSV(color, hsv)
                    refresh()
                }
                row.addView(cell, LinearLayout.LayoutParams(0, (54 * dp).toInt(), 1f))
            }
            grid.addView(row)
        }
        root.addView(grid)

        val btns = LinearLayout(ctx)
        btns.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        fun btn(t: String, fg: Int, bgc: Int?, a: () -> Unit) {
            val v = txt(t, 18f, fg, bold = true)
            v.gravity = Gravity.CENTER
            v.setPadding((22 * dp).toInt(), (14 * dp).toInt(), (22 * dp).toInt(), (14 * dp).toInt())
            if (bgc != null) {
                val g = GradientDrawable()
                g.setColor(bgc)
                g.cornerRadius = 30 * dp
                v.background = g
            }
            v.setOnClickListener { a() }
            btns.addView(v)
        }
        if (allowAuto) btn("Авто", Color.WHITE, null) { dlg.dismiss(); onResult(null) }
        btn("Отмена", Color.WHITE, null) { dlg.dismiss() }
        btn("Готово", 0xFF2B2930.toInt(), 0xFFC9C3DC.toInt()) {
            dlg.dismiss()
            onResult(Color.HSVToColor(hsv))
        }
        root.addView(btns)

        val scroll = ScrollView(ctx)
        scroll.addView(root)
        dlg.setContentView(scroll)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dlg.window?.setLayout((ctx.resources.displayMetrics.widthPixels * 0.92f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        refresh()
        dlg.show()
    }
}
