package com.example.iosboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val preview = KeyboardView(this)
        val edit = EditText(this)
        edit.hint = "Проверка клавиатуры"
        edit.inputType = InputType.TYPE_NULL
        edit.showSoftInputOnFocusCompat()
        preview.listener = object : KeyListener {
            override fun onText(s: String) {
                edit.text.insert(edit.selectionStart.coerceAtLeast(0), s)
            }
            override fun onDelete() {
                val st = edit.selectionStart
                if (st > 0) edit.text.delete(st - 1, st)
            }
            override fun onEnter() { edit.text.insert(edit.selectionStart.coerceAtLeast(0), "\n") }
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun button(t: String, a: () -> Unit) {
            val bt = Button(this); bt.text = t; bt.setOnClickListener { a() }; col.addView(bt)
        }
        button("1. Включить клавиатуру") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        button("2. Выбрать клавиатуру") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }

        fun slider(title: String, min: Int, max: Int, value: Int, key: String, unit: String, zero: String? = null) {
            fun txt(v: Int) = if (v == 0 && zero != null) "$title: $zero" else "$title: $v $unit"
            val label = TextView(this)
            label.text = txt(value)
            label.setPadding(0, pad, 0, 0)
            val sb = SeekBar(this)
            sb.max = max - min
            sb.progress = value - min
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    val v = p + min
                    label.text = txt(v)
                    Prefs.set(this@SettingsActivity, key, v)
                    preview.reloadPrefs()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(label); col.addView(sb)
        }
        slider("Скругление клавиш", 0, 23, Prefs.radius(this), "radius", "dp")
        slider("Отступ по бокам", 0, 32, Prefs.side(this), "side", "dp")
        slider("Отступ снизу", 0, 48, Prefs.bottom(this), "bottom", "dp")

        val sw = Switch(this)
        sw.text = "Символы-подсказки при долгом нажатии"
        sw.isChecked = Prefs.hints(this)
        sw.setPadding(0, pad, 0, 0)
        sw.setOnCheckedChangeListener { _, on -> Prefs.set(this, "hints", on); preview.reloadPrefs() }
        col.addView(sw)
        slider("Время долгого нажатия", 150, 800, Prefs.longMs(this), "longMs", "мс")

        fun toggle(title: String, key: String, value: Boolean) {
            val s = Switch(this)
            s.text = title
            s.isChecked = value
            s.setPadding(0, pad, 0, 0)
            s.setOnCheckedChangeListener { _, on -> Prefs.set(this, key, on); preview.reloadPrefs() }
            col.addView(s)
        }
        toggle("Маленькие символы-подсказки на клавишах", "cornerHints", Prefs.cornerHints(this))
        toggle("Звук нажатий (как в системе)", "sound", Prefs.sound(this))
        toggle("Разные звуки для пробела, Backspace и Enter", "distinct", Prefs.distinct(this))
        slider("Громкость звука нажатий", 0, 100, Prefs.volume(this), "volume", "%", "как в системе")
        slider("Высота клавиш", 36, 64, Prefs.keyH(this), "keyH", "dp")
        slider("Ширина клавиш", 60, 100, Prefs.keyW(this), "keyW", "%")
        slider("Расстояние между клавишами", 0, 12, Prefs.gapX(this), "gapX", "dp", "0 (вплотную)")
        slider("Расстояние между рядами", 0, 20, Prefs.gapY(this), "gapY", "dp", "0 (вплотную)")
        toggle("Растягивать средний ряд до краёв", "stretch", Prefs.stretch(this))
        toggle("Ряд цифр сверху", "numRow", Prefs.numRow(this))

        val symLabels = listOf("Нет", ",", ".", "?", "!", "@")
        val symValues = listOf("", ",", ".", "?", "!", "@")
        fun picker(title: String, key: String, current: String) {
            val t = TextView(this)
            t.text = title
            t.setPadding(0, pad, 0, 0)
            col.addView(t)
            val spn = Spinner(this)
            val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, symLabels)
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spn.adapter = ad
            spn.setSelection(symValues.indexOf(current).coerceAtLeast(0))
            spn.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    Prefs.setStr(this@SettingsActivity, key, symValues[pos])
                    preview.reloadPrefs()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            col.addView(spn)
        }
        picker("Символ слева от пробела", "symL", Prefs.symL(this))
        picker("Символ справа от пробела", "symR", Prefs.symR(this))
        toggle("Показывать ряд своих клавиш", "customOn", Prefs.customOn(this))
        val ct = TextView(this)
        ct.text = "Свои клавиши (через пробел, до 12 штук)"
        ct.setPadding(0, pad, 0, 0)
        col.addView(ct)
        val ce = EditText(this)
        ce.hint = "Например: @ # _ ~ :) @gmail.com"
        ce.setText(Prefs.custom(this))
        ce.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                Prefs.setStr(this@SettingsActivity, "custom", s?.toString() ?: "")
                preview.reloadPrefs()
            }
        })
        col.addView(ce)

        fun radios(title: String, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
            val t = TextView(this); t.text = title; t.setPadding(0, pad, 0, 0); col.addView(t)
            val g = RadioGroup(this)
            items.forEachIndexed { i, s ->
                val r = RadioButton(this); r.text = s; r.id = i + 1000; g.addView(r)
            }
            g.check(selected + 1000)
            g.setOnCheckedChangeListener { _, id -> onPick(id - 1000) }
            col.addView(g)
        }
        radios("Кнопка эмодзи", listOf("Под клавиатурой (как на iPhone)", "В самой клавиатуре (как на Android)"),
            if (Prefs.emojiBelow(this)) 0 else 1) {
            Prefs.set(this, "emojiBelow", it == 0); preview.reloadPrefs()
        }
        radios("Тема", listOf("Как в системе", "Светлая", "Тёмная", "Серая"), Prefs.theme(this)) {
            Prefs.set(this, "theme", it); preview.reloadPrefs()
        }

        val scroll = ScrollView(this)
        scroll.addView(col)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(edit, LinearLayout.LayoutParams(-1, -2))
        root.addView(preview, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun EditText.showSoftInputOnFocusCompat() {
        showSoftInputOnFocus = false
    }
}
