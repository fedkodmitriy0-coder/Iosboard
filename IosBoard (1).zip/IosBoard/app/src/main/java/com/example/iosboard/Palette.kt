package com.example.iosboard

/** Built-in colour sets: [background, key, space, special key, text]. */
object Palette {
    fun builtIn(theme: Int, systemDark: Boolean): IntArray {
        val t = if (theme == 0) (if (systemDark) 2 else 1) else theme
        return when (t) {
            2 -> intArrayOf(0xFF1B1B1D.toInt(), 0xFF6A6A6C.toInt(), 0xFF6A6A6C.toInt(), 0xFF454547.toInt(), 0xFFFFFFFF.toInt())
            3 -> intArrayOf(0xFF4A4C50.toInt(), 0xFF7C7F85.toInt(), 0xFF7C7F85.toInt(), 0xFF63666B.toInt(), 0xFFFFFFFF.toInt())
            else -> intArrayOf(0xFFD2D4DA.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFAEB3BE.toInt(), 0xFF000000.toInt())
        }
    }
}
