package com.example.iosboard

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("kb", Context.MODE_PRIVATE)
    fun radius(c: Context) = sp(c).getInt("radius", 8)          // dp, 0..23
    fun side(c: Context) = sp(c).getInt("side", 3)              // dp, 0..32
    fun bottom(c: Context) = sp(c).getInt("bottom", 4)          // dp, 0..48
    fun emojiBelow(c: Context) = sp(c).getBoolean("emojiBelow", true)
    fun theme(c: Context) = sp(c).getInt("theme", 0)            // 0 auto, 1 light, 2 dark
    fun hints(c: Context) = sp(c).getBoolean("hints", true)     // symbols popup on long press
    fun longMs(c: Context) = sp(c).getInt("longMs", 350)        // ms, 150..800
    fun cornerHints(c: Context) = sp(c).getBoolean("cornerHints", true) // small hint symbol on keys
    fun sound(c: Context) = sp(c).getBoolean("sound", true)             // system key click sound
    fun set(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
    fun set(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
}
