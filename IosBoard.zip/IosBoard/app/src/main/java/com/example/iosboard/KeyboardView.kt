package com.example.iosboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.PopupWindow

interface KeyListener {
    fun onText(s: String)
    fun onDelete()
    fun onEnter()
    fun onPickIme() {}
}

class KeyboardView(context: Context) : View(context) {
    var listener: KeyListener? = null

    // style: -1 spacer, 0 letter, 1 special, 2 emoji/icon (no bg), 3 space, 4 text button (no bg)
    private class Spec(val token: String, val label: String, val weight: Float, val style: Int)
    private class Key(val spec: Spec, val r: RectF)

    private companion object {
        const val HEAD = 56f      // headroom for the key balloon, dp
        const val KEY_H = 46f
        const val ROW_GAP = 11f
        const val STRIP_H = 40f   // strip under the keys (emoji below), dp
        val EMOJIS = listOf(
            "😀", "😂", "🥹", "😍", "😘", "😎", "🤔", "😢",
            "😭", "😡", "🥳", "😴", "👍", "👎", "👏", "🙏",
            "💪", "👀", "🔥", "❤️", "💔", "🎉", "✨", "💯"
        )
        val EN = arrayOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        val RU = arrayOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")
        val SYM = arrayOf("1234567890", "-/:;()₽&@\"", ".,?!'#%")

        // Long-press variants (first item sits right above the pressed key)
        val VARIANTS = mapOf(
            "q" to "1", "w" to "2", "e" to "3èéêëēėę", "r" to "4", "t" to "5",
            "y" to "6ÿý", "u" to "7ùúûüū", "i" to "8ìíîïīį", "o" to "9òóôöõøœō", "p" to "0",
            "a" to "àáâäæãåā", "s" to "ßśš", "d" to "ď", "f" to "ƒ", "g" to "ğ", "h" to "ħ",
            "k" to "ķ", "l" to "ł", "z" to "žźż", "x" to "×", "c" to "çćč", "n" to "ñń", "m" to "µ",
            "й" to "1", "ц" to "2", "у" to "3", "к" to "4", "е" to "5ё", "н" to "6",
            "г" to "7", "ш" to "8", "щ" to "9", "з" to "0", "ь" to "ъ",
            "1" to "¹½⅓¼", "2" to "²⅔", "3" to "³¾", "4" to "⁴", "5" to "⁵",
            "6" to "⁶", "7" to "⁷", "8" to "⁸", "9" to "⁹", "0" to "°⁰ⁿ∅",
            "." to "…·", "," to "‚", "?" to "¿", "!" to "¡", "'" to "‘’‚‹›",
            "\"" to "“”„«»", "-" to "–—•", "/" to "\\|", "(" to "[{<", ")" to "]}>",
            "&" to "§", "₽" to "€£¥¢$", "%" to "‰", "#" to "№"
        )
    }

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keys = ArrayList<Key>()
    private var radius = 8
    private var side = 3
    private var bottom = 4
    private var emojiBelow = true
    private var theme = 0
    private var hintsOn = true
    private var longMs = 350
    private var cornerOn = true
    private var soundOn = true
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var lang = 0
    private var shift = false
    private var caps = false
    private var symbols = false
    private var emoji = false
    private var pressed: Key? = null
    private var repeated = false
    private var longHandled = false
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var popup: PopupWindow? = null
    private var popupView: VariantView? = null
    private var popupX = 0
    private var popupY = 0
    private val handler = Handler(Looper.getMainLooper())
    private val repeatTask = object : Runnable {
        override fun run() {
            repeated = true
            listener?.onDelete()
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            click("DEL")
            handler.postDelayed(this, 50)
        }
    }
    private val longTask = Runnable { pressed?.let { startLong(it) } }

    init { reloadPrefs() }

    fun reloadPrefs() {
        radius = Prefs.radius(context)
        side = Prefs.side(context)
        bottom = Prefs.bottom(context)
        emojiBelow = Prefs.emojiBelow(context)
        theme = Prefs.theme(context)
        hintsOn = Prefs.hints(context)
        longMs = Prefs.longMs(context)
        cornerOn = Prefs.cornerHints(context)
        soundOn = Prefs.sound(context)
        requestLayout()
        build()
        invalidate()
    }

    private fun totalH(): Int {
        var h = HEAD + 4 * KEY_H + 3 * ROW_GAP
        h += if (emojiBelow) 2 + STRIP_H else 6f
        h += bottom
        return (h * dp).toInt()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), totalH())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        build()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeatTask)
        handler.removeCallbacks(longTask)
        dismissPopup()
        super.onDetachedFromWindow()
    }

    private fun ch(c: Char) = Spec("CH", c.toString(), 1f, 0)

    private fun rowsFor(): List<List<Spec>> {
        val out = ArrayList<List<Spec>>()
        if (emoji) {
            for (r in 0 until 3) out.add((0 until 8).map { Spec("CH", EMOJIS[r * 8 + it], 1f, 2) })
            out.add(
                if (emojiBelow) listOf(Spec("SPACE", "", 6f, 3), Spec("DEL", "⌫", 2f, 1))
                else listOf(Spec("ABC", "ABC", 2f, 1), Spec("SPACE", "", 4f, 3), Spec("DEL", "⌫", 2f, 1))
            )
            return out
        }
        val l = if (symbols) SYM else if (lang == 0) EN else RU
        val r1 = l[0].map { ch(it) }
        val r2 = l[1].map { ch(it) }
        val left = if (symbols) Spec("", "", 1.5f, -1) else Spec("SHIFT", "⇧", 1.5f, 1)
        val r3 = listOf(left) + l[2].map { ch(it) } + Spec("DEL", "⌫", 1.5f, 1)
        out.add(r1); out.add(r2); out.add(r3)
        val max = r1.sumOf { it.weight.toDouble() }.toFloat()
        val b = ArrayList<Spec>()
        if (symbols) b.add(Spec("ABC", "ABC", 1.5f, 1)) else b.add(Spec("SYM", "123", 1.5f, 1))
        if (!emojiBelow && !symbols) {
            b.add(Spec("EMOJI", "😀", 1f, 1))
            b.add(Spec("LANG", "🌐", 1f, 1))
        }
        val enter = Spec("ENTER", "⏎", 2f, 1)
        val used = b.sumOf { it.weight.toDouble() }.toFloat() + enter.weight
        b.add(Spec("SPACE", "", max - used, 3))
        b.add(enter)
        out.add(b)
        return out
    }

    private fun build() {
        keys.clear()
        val w = width
        if (w == 0) return
        val s = side * dp
        val availW = w - 2 * s
        val rows = rowsFor()
        val maxSum = rows[0].sumOf { it.weight.toDouble() }.toFloat()
        val unit = availW / maxSum
        for ((i, row) in rows.withIndex()) {
            val total = row.sumOf { it.weight.toDouble() }.toFloat() * unit
            var x = s + (availW - total) / 2
            val top = (HEAD + i * (KEY_H + ROW_GAP)) * dp
            for (sp in row) {
                val kw = sp.weight * unit
                if (sp.style >= 0) keys.add(Key(sp, RectF(x + 3 * dp, top, x + kw - 3 * dp, top + KEY_H * dp)))
                x += kw
            }
        }
        if (emojiBelow) {
            val top = (HEAD + 4 * KEY_H + 3 * ROW_GAP + 2) * dp
            val sz = STRIP_H * dp + 8 * dp
            var x = s + 4 * dp
            val strip = if (emoji) listOf(Spec("ABC", "ABC", 1f, 4))
            else listOf(Spec("EMOJI", "😀", 1f, 2), Spec("LANG", "🌐", 1f, 2))
            for (sp in strip) {
                keys.add(Key(sp, RectF(x, top, x + sz, top + STRIP_H * dp)))
                x += sz
            }
        }
    }

    private fun isDark(): Boolean = when (theme) {
        1 -> false
        2 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private val bgC get() = if (isDark()) 0xFF1B1B1D.toInt() else 0xFFD2D4DA.toInt()
    private val letterC get() = if (isDark()) 0xFF6A6A6C.toInt() else 0xFFFFFFFF.toInt()
    private val specialC get() = if (isDark()) 0xFF454547.toInt() else 0xFFAEB3BE.toInt()
    private val shadowC get() = if (isDark()) 0xFF000000.toInt() else 0xFF898A8D.toInt()
    private val textC get() = if (isDark()) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()

    // Plays the phone's own key-click sounds; Android skips it if system touch sounds are off.
    private fun click(token: String) {
        if (!soundOn) return
        val fx = when (token) {
            "SPACE" -> AudioManager.FX_KEYPRESS_SPACEBAR
            "DEL" -> AudioManager.FX_KEYPRESS_DELETE
            "ENTER" -> AudioManager.FX_KEYPRESS_RETURN
            else -> AudioManager.FX_KEYPRESS_STANDARD
        }
        audio.playSoundEffect(fx, -1f)
    }

    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    override fun onDraw(c: Canvas) {
        val letter = letterC
        val special = specialC
        val shadow = shadowC
        val text = textC
        c.drawColor(bgC)
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        for (k in keys) {
            val st = k.spec.style
            val on = k === pressed
            val active = k.spec.token == "SHIFT" && shift
            val rad = minOf(radius * dp, k.r.height() / 2)
            if (st == 0 || st == 1 || st == 3) {
                val base = if (st == 1 && !active) special else letter
                val col = if (on) (if (base == letter) special else letter) else base
                paint.color = shadow
                c.drawRoundRect(k.r.left, k.r.top + dp, k.r.right, k.r.bottom + dp, rad, rad, paint)
                paint.color = col
                c.drawRoundRect(k.r, rad, rad, paint)
            } else if (on) {
                paint.color = special
                paint.alpha = 110
                c.drawRoundRect(k.r, rad, rad, paint)
                paint.alpha = 255
            }
            if (k.spec.label.isEmpty()) continue
            paint.color = text
            paint.textSize = when (st) { 0 -> sp(22f); 2 -> sp(24f); 4 -> sp(16f); else -> sp(16f) }
            val label = when {
                shift && st == 0 && k.spec.token == "CH" -> k.spec.label.uppercase()
                k.spec.token == "SHIFT" && caps -> "⇪"
                else -> k.spec.label
            }
            c.drawText(label, k.r.centerX(), k.r.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
            if (cornerOn && hintsOn && st == 0 && k.spec.token == "CH") {
                val hint = variantsFor(k.spec.label).firstOrNull()
                if (hint != null) {
                    paint.textSize = sp(10f)
                    paint.alpha = 140
                    c.drawText(hint, k.r.right - 8 * dp, k.r.top + 13 * dp, paint)
                    paint.alpha = 255
                }
            }
        }
        val k = pressed
        if (popupView == null && k != null && k.spec.token == "CH" && k.spec.style == 0) {
            val w = k.r.width() + 14 * dp
            val l = (k.r.centerX() - w / 2).coerceIn(2 * dp, width - w - 2 * dp)
            val b = k.r.top - 4 * dp
            val rect = RectF(l, b - 48 * dp, l + w, b)
            val rad = minOf(radius * dp + 4 * dp, 24 * dp)
            paint.color = shadow
            c.drawRoundRect(rect.left, rect.top + dp, rect.right, rect.bottom + dp, rad, rad, paint)
            paint.color = letter
            c.drawRoundRect(rect, rad, rad, paint)
            paint.color = text
            paint.textSize = sp(34f)
            val label = if (shift) k.spec.label.uppercase() else k.spec.label
            c.drawText(label, rect.centerX(), rect.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
        }
    }

    // ---- long-press popup (up to 2 rows) ----

    private inner class VariantView(
        ctx: Context, val items: List<String>, val cols: Int, val rows: Int,
        val cellW: Float, val cellH: Float, val pad: Float, val rtl: Boolean
    ) : View(ctx) {
        var selected = 0
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val rad = minOf(radius * dp + 6 * dp, 20 * dp)
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.color = shadowC
            c.drawRoundRect(0f, dp, w, h, rad, rad, p)
            p.color = letterC
            c.drawRoundRect(0f, 0f, w, h - dp, rad, rad, p)
            p.textSize = sp(24f)
            for ((i, s) in items.withIndex()) {
                val rowB = i / cols
                val colRaw = i % cols
                val col = if (rtl) cols - 1 - colRaw else colRaw
                val rowT = rows - 1 - rowB
                val rect = RectF(pad + col * cellW, pad + rowT * cellH, pad + (col + 1) * cellW, pad + (rowT + 1) * cellH)
                if (i == selected) {
                    p.color = 0xFF0A84FF.toInt()
                    c.drawRoundRect(rect.left + 2 * dp, rect.top + 2 * dp, rect.right - 2 * dp, rect.bottom - 2 * dp, 8 * dp, 8 * dp, p)
                    p.color = 0xFFFFFFFF.toInt()
                } else p.color = textC
                c.drawText(s, rect.centerX(), rect.centerY() - (p.descent() + p.ascent()) / 2, p)
            }
        }
    }

    private fun variantsFor(label: String): List<String> {
        val s = VARIANTS[label.lowercase()] ?: return emptyList()
        val list = s.map { it.toString() }
        return if (shift) list.map { it.uppercase() } else list
    }

    private fun canLong(k: Key): Boolean = when (k.spec.token) {
        "SHIFT", "LANG" -> true
        "CH" -> hintsOn && k.spec.style == 0 && variantsFor(k.spec.label).isNotEmpty()
        else -> false
    }

    private fun startLong(k: Key) {
        when (k.spec.token) {
            "SHIFT" -> {
                shift = true; caps = true; longHandled = true
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                invalidate()
            }
            "LANG" -> {
                longHandled = true; pressed = null
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                invalidate()
                listener?.onPickIme()
            }
            "CH" -> {
                val v = variantsFor(k.spec.label)
                if (v.isEmpty()) return
                showPopup(k, v)
                longHandled = true
            }
        }
    }

    private fun showPopup(k: Key, v: List<String>) {
        val rows = if (v.size > 4) 2 else 1
        val cols = (v.size + rows - 1) / rows
        val cw = 42 * dp
        val chh = 50 * dp
        val pad = 6 * dp
        val w = (cols * cw + 2 * pad).toInt()
        val h = (rows * chh + 2 * pad).toInt()
        val rtl = k.r.centerX() > width / 2f
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        var x = if (rtl) (loc[0] + k.r.centerX() + pad + cw / 2 - w).toInt()
        else (loc[0] + k.r.centerX() - pad - cw / 2).toInt()
        x = x.coerceIn(loc[0], maxOf(loc[0], loc[0] + width - w))
        val y = maxOf(0, (loc[1] + k.r.top - h - 6 * dp).toInt())
        val pv = VariantView(context, v, cols, rows, cw, chh, pad, rtl)
        val pw = PopupWindow(pv, w, h, false)
        pw.isTouchable = false
        pw.isClippingEnabled = false
        pw.showAtLocation(this, Gravity.NO_GRAVITY, x, y)
        popup = pw
        popupView = pv
        popupX = x
        popupY = y
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        updateSel(lastRawX, lastRawY, false)
        invalidate()
    }

    private fun updateSel(rawX: Float, rawY: Float, haptic: Boolean = true) {
        val pv = popupView ?: return
        val colRaw = ((rawX - popupX - pv.pad) / pv.cellW).toInt().coerceIn(0, pv.cols - 1)
        val col = if (pv.rtl) pv.cols - 1 - colRaw else colRaw
        val rowT = ((rawY - popupY - pv.pad) / pv.cellH).toInt().coerceIn(0, pv.rows - 1)
        val rowB = pv.rows - 1 - rowT
        val idx = (rowB * pv.cols + col).coerceAtMost(pv.items.size - 1)
        if (idx != pv.selected) {
            pv.selected = idx
            pv.invalidate()
            if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }

    private fun dismissPopup() {
        popup?.dismiss()
        popup = null
        popupView = null
    }

    // ---- touch ----

    private fun hit(x: Float, y: Float): Key? {
        val ex = 3 * dp
        val ey = ROW_GAP * dp / 2
        return keys.firstOrNull {
            x >= it.r.left - ex && x <= it.r.right + ex && y >= it.r.top - ey && y <= it.r.bottom + ey
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        lastRawX = e.rawX
        lastRawY = e.rawY
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                if (popupView != null) {
                    updateSel(e.rawX, e.rawY)
                    return true
                }
                val k = hit(e.x, e.y)
                if (k !== pressed) {
                    handler.removeCallbacks(repeatTask)
                    handler.removeCallbacks(longTask)
                    repeated = false
                    longHandled = false
                    pressed = k
                    if (k != null) {
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        click(k.spec.token)
                        if (k.spec.token == "DEL") handler.postDelayed(repeatTask, 400)
                        else if (canLong(k)) handler.postDelayed(longTask, longMs.toLong())
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(repeatTask)
                handler.removeCallbacks(longTask)
                val k = pressed
                pressed = null
                val pv = popupView
                if (pv != null) {
                    commit(pv.items[pv.selected])
                    dismissPopup()
                } else if (k != null && !longHandled) fire(k)
                longHandled = false
                repeated = false
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeatTask)
                handler.removeCallbacks(longTask)
                dismissPopup()
                pressed = null
                repeated = false
                longHandled = false
                invalidate()
            }
        }
        return true
    }

    private fun commit(s: String) {
        listener?.onText(s)
        if (shift && !caps) shift = false
    }

    private fun fire(k: Key) {
        when (k.spec.token) {
            "CH" -> commit(if (shift && k.spec.style == 0) k.spec.label.uppercase() else k.spec.label)
            "SPACE" -> listener?.onText(" ")
            "DEL" -> if (!repeated) listener?.onDelete()
            "ENTER" -> listener?.onEnter()
            "SHIFT" -> { if (shift) { shift = false; caps = false } else shift = true }
            "SYM" -> { symbols = true; build() }
            "ABC" -> { symbols = false; emoji = false; build() }
            "LANG" -> { lang = 1 - lang; symbols = false; build() }
            "EMOJI" -> { emoji = true; build() }
        }
    }
}
