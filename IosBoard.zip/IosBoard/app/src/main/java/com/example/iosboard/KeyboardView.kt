package com.example.iosboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.PopupWindow
import android.widget.Toast
import kotlin.math.abs

interface KeyListener {
    fun onText(s: String)
    fun onDelete()
    fun onEnter()
    fun onPickIme() {}
    fun onEdit(action: String, select: Boolean) {}
    fun onSuggestion(s: String) {}
    fun onOpenSettings() {}
}

class KeyboardView(context: Context) : View(context) {
    var listener: KeyListener? = null

    // style: -1 spacer, 0 letter, 1 special, 2 emoji/icon (no bg), 3 space, 4 text button (no bg)
    private class Spec(val token: String, val label: String, val weight: Float, val style: Int)
    private class Key(val spec: Spec, val r: RectF)

    private companion object {
        const val HEAD = 56f      // headroom for the key balloon, dp
        const val STRIP_H = 40f   // strip under the keys (emoji below), dp
        const val TOOL_H = 36f    // editor toolbar, dp
        const val SUG_H = 36f     // suggestion strip, dp
        val EMOJIS = listOf(
            "😀", "😂", "🥹", "😍", "😘", "😎", "🤔", "😢",
            "😭", "😡", "🥳", "😴", "👍", "👎", "👏", "🙏",
            "💪", "👀", "🔥", "❤️", "💔", "🎉", "✨", "💯"
        )
        val EN = arrayOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        val RU = arrayOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
        val SYM = arrayOf("1234567890", "-/:;()₽&@\"", ".,?!'#%")

        // Long-press variants (first item sits right above the pressed key)
        val VARIANTS = mapOf(
            "q" to "1", "w" to "2", "e" to "3èéêëēėę", "r" to "4", "t" to "5",
            "y" to "6ÿý", "u" to "7ùúûüū", "i" to "8ìíîïīį", "o" to "9òóôöõøœō", "p" to "0",
            "a" to "àáâäæãåā", "s" to "ßśš", "d" to "ď", "f" to "ƒ", "g" to "ğ", "h" to "ħ",
            "k" to "ķ", "l" to "ł", "z" to "žźż", "x" to "×", "c" to "çćč", "n" to "ñń", "m" to "µ",
            "й" to "1", "ц" to "2", "у" to "3", "к" to "4", "е" to "5ё", "н" to "6",
            "г" to "7", "ш" to "8", "щ" to "9", "з" to "0", "ь" to "ъ",
            "1" to "¹½⅓¼", "2" to "²⅔", "3" to "³¾", "4" to "⁴", "5" to "⁵",
            "6" to "⁶", "7" to "⁷", "8" to "⁸", "9" to "⁹", "0" to "°⁰ⁿ∅",
            "." to "…·", "," to "‚", "?" to "¿", "!" to "¡", "'" to "‘’‚‹›",
            "\"" to "“”„«»", "-" to "–—•", "/" to "\\|", "(" to "[{<", ")" to "]}>",
            "&" to "§", "₽" to "€£¥¢$", "%" to "‰", "#" to "№"
        )
    }

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keys = ArrayList<Key>()
    private var radius = 8
    private var side = 3
    private var bottom = 4
    private var emojiPos = 0
    private val emojiBelow get() = emojiPos == 0
    private var langMode = 0
    private var panelOn = true
    private var panelOpen = false
    private var spaceSwiped = false
    private var theme = 0
    private var hintsOn = true
    private var longMs = 350
    private var cornerOn = true
    private var soundOn = true
    private var keyH = 46f
    private var gapX = 6f
    private var stretch = true
    private var numRow = false
    private var editorBar = true
    private var suggestOn = true
    private var selectMode = false
    private var clipMode = false
    private var clipScroll = 0
    private var clips: List<String> = emptyList()
    private var suggestions: List<String> = emptyList()
    private var symL = ","
    private var symR = "."
    private var activeId = -1
    private var downX = 0f
    private var downY = 0f
    private val loc = IntArray(2)
    private var rowGap = 11f
    private var keyW = 100
    private var volume = 0
    private var distinctSound = true
    private var customOn = true
    private var customKeys: List<String> = emptyList()
    private var hitEx = 0f
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var lang = 0
    private var shift = false
    private var caps = false
    private var symbols = false
    private var emoji = false
    private var pressed: Key? = null
    private var repeated = false
    private var longHandled = false
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var popup: PopupWindow? = null
    private var popupView: VariantView? = null
    private var popupX = 0
    private var popupY = 0
    private val handler = Handler(Looper.getMainLooper())
    private val repeatTask = object : Runnable {
        override fun run() {
            repeated = true
            listener?.onDelete()
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            click("DEL")
            handler.postDelayed(this, 50)
        }
    }
    private val longTask = Runnable { pressed?.let { startLong(it) } }

    init { reloadPrefs() }

    fun reloadPrefs() {
        radius = Prefs.radius(context)
        side = Prefs.side(context)
        bottom = Prefs.bottom(context)
        emojiPos = Prefs.emojiPos(context)
        langMode = Prefs.langMode(context)
        panelOn = Prefs.panel(context)
        theme = Prefs.theme(context)
        hintsOn = Prefs.hints(context)
        longMs = Prefs.longMs(context)
        cornerOn = Prefs.cornerHints(context)
        soundOn = Prefs.sound(context)
        keyH = Prefs.keyH(context).toFloat()
        gapX = Prefs.gapX(context).toFloat()
        stretch = Prefs.stretch(context)
        numRow = Prefs.numRow(context)
        editorBar = Prefs.editorBar(context)
        suggestOn = Prefs.suggest(context)
        symL = Prefs.symL(context)
        symR = Prefs.symR(context)
        rowGap = Prefs.gapY(context).toFloat()
        keyW = Prefs.keyW(context)
        volume = Prefs.volume(context)
        distinctSound = Prefs.distinct(context)
        customOn = Prefs.customOn(context)
        customKeys = Prefs.custom(context).split(Regex("\\s+")).filter { it.isNotEmpty() }.take(12)
        requestLayout()
        build()
        invalidate()
    }

    private fun customRow() = customOn && customKeys.isNotEmpty()
    private fun barsH() = (if (editorBar) TOOL_H else 0f) + (if (suggestOn || panelOn) SUG_H else 0f)
    private fun topH() = maxOf(HEAD, barsH())
    private fun extraRows() = (if (customRow()) 1 else 0) + (if (numRow) 1 else 0)

    private fun totalH(): Int {
        val off = extraRows()
        var h = topH() + (4 + off) * keyH + (3 + off) * rowGap
        h += if (emojiBelow) 2 + STRIP_H else 6f
        h += bottom
        return (h * dp).toInt()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), totalH())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        build()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeatTask)
        handler.removeCallbacks(longTask)
        dismissPopup()
        super.onDetachedFromWindow()
    }

    private fun ch(c: Char) = Spec("CH", c.toString(), 1f, 0)

    private fun rowsFor(): List<List<Spec>> {
        val out = ArrayList<List<Spec>>()
        if (clipMode) {
            for (r in 0 until 3) {
                val idx = clipScroll + r
                out.add(
                    listOf(
                        when {
                            idx < clips.size -> Spec("CLIP", clips[idx], 10f, 5)
                            idx == 0 -> Spec("NOP", "Буфер обмена пуст", 10f, 5)
                            else -> Spec("", "", 10f, -1)
                        }
                    )
                )
            }
            out.add(
                listOf(
                    Spec("ABC", "ABC", 2f, 1), Spec("CLIPUP", "▲", 1.5f, 1),
                    Spec("CLIPDN", "▼", 1.5f, 1), Spec("CLIPCLR", "Очистить", 5f, 1)
                )
            )
            return out
        }
        if (emoji) {
            for (r in 0 until 3) out.add((0 until 8).map { Spec("CH", EMOJIS[r * 8 + it], 1f, 2) })
            out.add(
                if (emojiBelow) listOf(Spec("SPACE", "", 6f, 3), Spec("DEL", "⌫", 2f, 1))
                else listOf(Spec("ABC", "ABC", 2f, 1), Spec("SPACE", "", 4f, 3), Spec("DEL", "⌫", 2f, 1))
            )
            return out
        }
        val l = if (symbols) SYM else if (lang == 0) EN else RU
        val r1 = l[0].map { ch(it) }
        val r2 = l[1].map { ch(it) }
        val sw = (r1.size - l[2].length) / 2f
        val left = if (symbols) Spec("", "", sw, -1) else Spec("SHIFT", "⇧", sw, 1)
        val r3 = listOf(left) + l[2].map { ch(it) } + Spec("DEL", "⌫", sw, 1)
        out.add(r1); out.add(r2); out.add(r3)
        val max = r1.sumOf { it.weight.toDouble() }.toFloat()
        val b = ArrayList<Spec>()
        if (symbols) b.add(Spec("ABC", "ABC", 1.5f, 1)) else b.add(Spec("SYM", "123", 1.5f, 1))
        if (!symbols) {
            if (emojiPos == 1) b.add(Spec("EMOJI", "😀", 1f, 1))
            if (emojiPos != 0 && langMode == 0) b.add(Spec("LANG", "🌐", 1f, 1))
        }
        val enter = Spec("ENTER", "⏎", 2f, 1)
        val used = b.sumOf { it.weight.toDouble() }.toFloat() + enter.weight +
            (if (symL.isNotEmpty()) 1f else 0f) + (if (symR.isNotEmpty()) 1f else 0f)
        if (symL.isNotEmpty()) b.add(Spec("CH", symL, 1f, 0))
        b.add(Spec("SPACE", "", max - used, 3))
        if (symR.isNotEmpty()) b.add(Spec("CH", symR, 1f, 0))
        b.add(enter)
        out.add(b)
        return out
    }

    private fun keyRect(x: Float, kw: Float, top: Float): RectF {
        val cx = x + kw / 2
        val half = maxOf(kw * keyW / 200f - gapX * dp / 2, 4 * dp)
        return RectF(cx - half, top, cx + half, top + keyH * dp)
    }

    private fun build() {
        keys.clear()
        val w = width
        if (w == 0) return
        val s = side * dp
        val availW = w - 2 * s
        val rows = rowsFor()
        val maxSum = rows[0].sumOf { it.weight.toDouble() }.toFloat()
        val unit = availW / maxSum
        hitEx = gapX * dp / 2 + unit * (100 - keyW) / 200f
        var barY = 0f
        if (editorBar) {
            val toks = listOf("SELECT", "UP", "LEFT", "CASE", "RIGHT", "DOWN", "CUT", "COPY", "PASTE")
            val all = listOf("HOME") + toks + listOf("DEL", "END")
            val cw = availW / all.size
            for ((i, tk) in all.withIndex()) {
                keys.add(Key(Spec(if (tk == "DEL") "DEL" else "E_$tk", "", 1f, 6), RectF(s + i * cw, barY * dp, s + (i + 1) * cw, (barY + TOOL_H) * dp)))
            }
            barY += TOOL_H
        }
        if (suggestOn || panelOn) {
            var x0 = s
            if (panelOn) {
                keys.add(Key(Spec("P_GRID", "", 1f, 6), RectF(s, barY * dp, s + 44 * dp, (barY + SUG_H) * dp)))
                x0 = s + 44 * dp
            }
            val w2 = availW - (x0 - s)
            if (panelOn && panelOpen) {
                val toks = ArrayList<String>()
                toks.addAll(listOf("P_TR1", "P_TR2", "P_WAND", "P_CLIP"))
                if (emojiPos == 2) toks.add("P_EMOJI")
                toks.add("P_GEAR")
                val cw = w2 / toks.size
                for ((i, tk) in toks.withIndex()) {
                    keys.add(Key(Spec(tk, "", 1f, 6), RectF(x0 + i * cw, barY * dp, x0 + (i + 1) * cw, (barY + SUG_H) * dp)))
                }
            } else if (suggestOn) {
                val items = suggestions.take(3)
                if (items.isNotEmpty()) {
                    val cw = w2 / items.size
                    for ((i, sg) in items.withIndex()) {
                        keys.add(Key(Spec("SUG", sg, 1f, 7), RectF(x0 + i * cw, barY * dp, x0 + (i + 1) * cw, (barY + SUG_H) * dp)))
                    }
                }
            }
            barY += SUG_H
        }
        val off = extraRows()
        var ri = 0
        if (customRow()) {
            val n = customKeys.size
            val uc = availW / maxOf(n, 5)
            var x = s + (availW - n * uc) / 2
            val top = (topH() + ri * (keyH + rowGap)) * dp
            for (txt in customKeys) {
                keys.add(Key(Spec("CUSTOM", txt, 1f, 0), keyRect(x, uc, top)))
                x += uc
            }
            ri++
        }
        if (numRow) {
            val un = availW / 10
            var x = s
            val top = (topH() + ri * (keyH + rowGap)) * dp
            for (d in "1234567890") {
                keys.add(Key(Spec("CH", d.toString(), 1f, 0), keyRect(x, un, top)))
                x += un
            }
            ri++
        }
        for ((i, row) in rows.withIndex()) {
            val rowSum = row.sumOf { it.weight.toDouble() }.toFloat()
            val u = if (stretch && !emoji && i == 1 && rowSum < maxSum) availW / rowSum else unit
            val total = rowSum * u
            var x = s + (availW - total) / 2
            val top = (topH() + (i + off) * (keyH + rowGap)) * dp
            for (sp in row) {
                val kw = sp.weight * u
                if (sp.style >= 0) keys.add(Key(sp, keyRect(x, kw, top)))
                x += kw
            }
        }
        if (emojiBelow) {
            val top = (topH() + (4 + off) * keyH + (3 + off) * rowGap + 2) * dp
            val sz = STRIP_H * dp + 8 * dp
            var x = s + 4 * dp
            val strip = if (emoji) listOf(Spec("ABC", "ABC", 1f, 4))
            else listOf(Spec("EMOJI", "😀", 1f, 2)) + (if (langMode == 0) listOf(Spec("LANG", "🌐", 1f, 2)) else emptyList())
            for (sp in strip) {
                keys.add(Key(sp, RectF(x, top, x + sz, top + STRIP_H * dp)))
                x += sz
            }
        }
    }

    private fun isDark(): Boolean = when (theme) {
        1 -> false
        2 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private val bgC get() = if (theme == 3) 0xFF4A4C50.toInt() else if (isDark()) 0xFF1B1B1D.toInt() else 0xFFD2D4DA.toInt()
    private val letterC get() = if (theme == 3) 0xFF7C7F85.toInt() else if (isDark()) 0xFF6A6A6C.toInt() else 0xFFFFFFFF.toInt()
    private val specialC get() = if (theme == 3) 0xFF63666B.toInt() else if (isDark()) 0xFF454547.toInt() else 0xFFAEB3BE.toInt()
    private val shadowC get() = if (theme == 3) 0xFF2B2C2F.toInt() else if (isDark()) 0xFF000000.toInt() else 0xFF898A8D.toInt()
    private val textC get() = if (theme == 3) 0xFFFFFFFF.toInt() else if (isDark()) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()

    // Plays the phone's own key-click sounds; Android skips it if system touch sounds are off.
    private fun click(token: String) {
        if (!soundOn) return
        val fx = if (!distinctSound) AudioManager.FX_KEYPRESS_STANDARD else when (token) {
            "SPACE" -> AudioManager.FX_KEYPRESS_SPACEBAR
            "DEL" -> AudioManager.FX_KEYPRESS_DELETE
            "ENTER" -> AudioManager.FX_KEYPRESS_RETURN
            else -> AudioManager.FX_KEYPRESS_STANDARD
        }
        audio.playSoundEffect(fx, if (volume <= 0) -1f else volume / 100f)
    }

    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    override fun onDraw(c: Canvas) {
        val letter = letterC
        val special = specialC
        val shadow = shadowC
        val text = textC
        c.drawColor(bgC)
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        for (k in keys) {
            val st = k.spec.style
            val on = k === pressed
            val active = k.spec.token == "SHIFT" && shift
            val rad = minOf(radius * dp, k.r.height() / 2)
            if (st == 0 || st == 1 || st == 3 || st == 5) {
                val base = if (st == 1 && !active) special else letter
                val col = if (on) (if (base == letter) special else letter) else base
                paint.color = shadow
                c.drawRoundRect(k.r.left, k.r.top + dp, k.r.right, k.r.bottom + dp, rad, rad, paint)
                paint.color = col
                c.drawRoundRect(k.r, rad, rad, paint)
            } else if (on) {
                paint.color = special
                paint.alpha = 110
                c.drawRoundRect(k.r, rad, rad, paint)
                paint.alpha = 255
            }
            if (st == 6) {
                drawIcon(c, k)
                continue
            }
            if (st == 5) {
                paint.color = text
                paint.textSize = sp(16f)
                paint.textAlign = Paint.Align.LEFT
                val tt = fit(k.spec.label.replace('\n', ' '), k.r.width() - 24 * dp)
                c.drawText(tt, k.r.left + 12 * dp, k.r.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
                paint.textAlign = Paint.Align.CENTER
                continue
            }
            if (st == 7) {
                paint.color = text
                paint.textSize = sp(17f)
                val tt = fit(k.spec.label, k.r.width() - 12 * dp)
                c.drawText(tt, k.r.centerX(), k.r.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
                paint.alpha = 70
                c.drawRect(k.r.right - dp / 2, k.r.top + 8 * dp, k.r.right + dp / 2, k.r.bottom - 8 * dp, paint)
                paint.alpha = 255
                continue
            }
            if (k.spec.label.isEmpty()) continue
            paint.color = text
            paint.textSize = when (st) { 0 -> sp(22f); 2 -> sp(24f); 4 -> sp(16f); else -> sp(16f) }
            val label = when {
                shift && st == 0 && k.spec.token == "CH" -> k.spec.label.uppercase()
                k.spec.token == "SHIFT" && caps -> "⇪"
                else -> k.spec.label
            }
            if (k.spec.token == "CUSTOM") {
                var z = sp(20f)
                paint.textSize = z
                val maxW = k.r.width() - 6 * dp
                while (paint.measureText(label) > maxW && z > sp(9f)) { z -= sp(1f); paint.textSize = z }
            }
            c.drawText(label, k.r.centerX(), k.r.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
            if (cornerOn && hintsOn && st == 0 && k.spec.token == "CH") {
                val hint = variantsFor(k.spec.label).firstOrNull()
                if (hint != null) {
                    paint.textSize = sp(10f)
                    paint.alpha = 140
                    c.drawText(hint, k.r.right - 8 * dp, k.r.top + 13 * dp, paint)
                    paint.alpha = 255
                }
            }
        }
        val k = pressed
        if (popupView == null && k != null && k.spec.token == "CH" && k.spec.style == 0) {
            val w = k.r.width() + 14 * dp
            val l = (k.r.centerX() - w / 2).coerceIn(2 * dp, width - w - 2 * dp)
            val b = k.r.top - 4 * dp
            val rect = RectF(l, b - 48 * dp, l + w, b)
            val rad = minOf(radius * dp + 4 * dp, 24 * dp)
            paint.color = shadow
            c.drawRoundRect(rect.left, rect.top + dp, rect.right, rect.bottom + dp, rad, rad, paint)
            paint.color = letter
            c.drawRoundRect(rect, rad, rad, paint)
            paint.color = text
            paint.textSize = sp(34f)
            val label = if (shift) k.spec.label.uppercase() else k.spec.label
            c.drawText(label, rect.centerX(), rect.centerY() - (paint.descent() + paint.ascent()) / 2, paint)
        }
    }

    // ---- editor toolbar icons, suggestions ----

    private val ip = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    fun setSuggestions(list: List<String>) {
        if (list == suggestions) return
        suggestions = list
        val p = pressed
        build()
        if (p != null) pressed = keys.firstOrNull { it.spec.token == p.spec.token && it.spec.label == p.spec.label && it.r == p.r } ?: p
        invalidate()
    }

    fun langCode() = if (lang == 0) "en" else "ru"

    private fun fit(s: String, maxW: Float): String {
        if (paint.measureText(s) <= maxW) return s
        val n = paint.breakText(s, true, maxW - paint.measureText("…"), null)
        return s.substring(0, maxOf(n, 0)) + "…"
    }

    private fun drawIcon(c: Canvas, k: Key) {
        val cx = k.r.centerX()
        val cy = k.r.centerY()
        val u = dp
        ip.pathEffect = null
        ip.strokeWidth = 1.8f * u
        ip.color = if (k.spec.token == "E_SELECT" && selectMode) 0xFF0A84FF.toInt() else textC
        if (k.spec.token == "P_TR1" || k.spec.token == "P_TR2" || k.spec.token == "P_WAND") ip.alpha = 100
        fun ln(x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(cx + x1 * u, cy + y1 * u, cx + x2 * u, cy + y2 * u, ip)
        when (k.spec.token) {
            "E_LEFT" -> { ln(3f, -6f, -3f, 0f); ln(-3f, 0f, 3f, 6f) }
            "E_RIGHT" -> { ln(-3f, -6f, 3f, 0f); ln(3f, 0f, -3f, 6f) }
            "E_UP" -> { ln(-6f, 3f, 0f, -3f); ln(0f, -3f, 6f, 3f) }
            "E_DOWN" -> { ln(-6f, -3f, 0f, 3f); ln(0f, 3f, 6f, -3f) }
            "E_HOME" -> { ln(-7f, -6f, -7f, 6f); ln(5f, -6f, -1f, 0f); ln(-1f, 0f, 5f, 6f) }
            "E_END" -> { ln(7f, -6f, 7f, 6f); ln(-5f, -6f, 1f, 0f); ln(1f, 0f, -5f, 6f) }
            "E_SELECT" -> {
                ip.pathEffect = DashPathEffect(floatArrayOf(3f * u, 3f * u), 0f)
                c.drawRoundRect(cx - 7 * u, cy - 7 * u, cx + 7 * u, cy + 7 * u, 2 * u, 2 * u, ip)
                ip.pathEffect = null
            }
            "E_SELALL" -> {
                c.drawRoundRect(cx - 8 * u, cy - 7 * u, cx + 8 * u, cy + 7 * u, 2 * u, 2 * u, ip)
                paint.color = ip.color
                paint.textSize = sp(11f)
                c.drawText("A", cx, cy - (paint.descent() + paint.ascent()) / 2, paint)
            }
            "E_CUT" -> {
                c.drawCircle(cx - 3 * u, cy + 4 * u, 2.5f * u, ip)
                c.drawCircle(cx + 3 * u, cy + 4 * u, 2.5f * u, ip)
                ln(-3f, 2f, 3f, -7f); ln(3f, 2f, -3f, -7f)
            }
            "E_COPY" -> {
                c.drawRoundRect(cx - 7 * u, cy - 4 * u, cx + 3 * u, cy + 7 * u, 2 * u, 2 * u, ip)
                ln(-3f, -4f, -3f, -7f); ln(-3f, -7f, 7f, -7f); ln(7f, -7f, 7f, 4f); ln(7f, 4f, 3f, 4f)
            }
            "E_PASTE", "P_CLIP" -> {
                c.drawRoundRect(cx - 6 * u, cy - 6 * u, cx + 6 * u, cy + 7 * u, 2 * u, 2 * u, ip)
                c.drawRoundRect(cx - 3 * u, cy - 8 * u, cx + 3 * u, cy - 4 * u, 1.5f * u, 1.5f * u, ip)
                ln(-3f, 0f, 3f, 0f); ln(-3f, 3f, 3f, 3f)
            }
            "E_CASE" -> {
                paint.color = ip.color
                paint.textSize = sp(16f)
                c.drawText("Tт", cx, cy - (paint.descent() + paint.ascent()) / 2, paint)
            }
            "DEL" -> {
                ln(-8f, 0f, -4f, -6f); ln(-4f, -6f, 8f, -6f); ln(8f, -6f, 8f, 6f); ln(8f, 6f, -4f, 6f); ln(-4f, 6f, -8f, 0f)
                ln(-1f, -2.5f, 4f, 2.5f); ln(4f, -2.5f, -1f, 2.5f)
            }
            "P_GRID" -> {
                paint.color = ip.color
                c.drawRoundRect(cx - 7 * u, cy - 7 * u, cx - 1 * u, cy - 1 * u, 1.5f * u, 1.5f * u, paint)
                c.drawRoundRect(cx + 1 * u, cy - 7 * u, cx + 7 * u, cy - 1 * u, 1.5f * u, 1.5f * u, paint)
                c.drawRoundRect(cx - 7 * u, cy + 1 * u, cx - 1 * u, cy + 7 * u, 1.5f * u, 1.5f * u, paint)
                c.drawRoundRect(cx + 1 * u, cy + 1 * u, cx + 7 * u, cy + 7 * u, 1.5f * u, 1.5f * u, paint)
            }
            "P_TR1" -> {
                paint.color = ip.color
                paint.textSize = sp(13f)
                c.drawText("A↔Я", cx, cy - (paint.descent() + paint.ascent()) / 2, paint)
            }
            "P_TR2" -> {
                paint.color = ip.color
                paint.textSize = sp(15f)
                c.drawText("文A", cx, cy - (paint.descent() + paint.ascent()) / 2, paint)
            }
            "P_WAND" -> {
                ip.strokeWidth = 2.4f * u
                ln(-6f, 6f, 3f, -3f)
                ip.strokeWidth = 1.5f * u
                ln(5f, -8f, 5f, -4f); ln(3f, -6f, 7f, -6f)
                ln(-4f, -7f, -4f, -4f); ln(-5.5f, -5.5f, -2.5f, -5.5f)
            }
            "P_EMOJI" -> {
                c.drawCircle(cx, cy, 7 * u, ip)
                paint.color = ip.color
                c.drawCircle(cx - 2.5f * u, cy - 2 * u, 1f * u, paint)
                c.drawCircle(cx + 2.5f * u, cy - 2 * u, 1f * u, paint)
                c.drawArc(RectF(cx - 4 * u, cy - 3 * u, cx + 4 * u, cy + 4 * u), 20f, 140f, false, ip)
            }
            "P_GEAR" -> {
                c.drawCircle(cx, cy, 4.5f * u, ip)
                c.drawCircle(cx, cy, 1.8f * u, ip)
                for (i in 0 until 8) {
                    val a = Math.PI / 4 * i
                    val cs = Math.cos(a).toFloat()
                    val sn = Math.sin(a).toFloat()
                    c.drawLine(cx + cs * 5.5f * u, cy + sn * 5.5f * u, cx + cs * 8f * u, cy + sn * 8f * u, ip)
                }
            }
            "E_HIST" -> {
                c.drawCircle(cx, cy, 7 * u, ip)
                ln(0f, 0f, 0f, -4f); ln(0f, 0f, 3f, 2f)
            }
        }
    }

    // ---- long-press popup (up to 2 rows) ----

    private inner class VariantView(
        ctx: Context, val items: List<String>, val cols: Int, val rows: Int,
        val cellW: Float, val cellH: Float, val pad: Float, val rtl: Boolean
    ) : View(ctx) {
        var selected = 0
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val rad = minOf(radius * dp + 6 * dp, 20 * dp)
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.color = shadowC
            c.drawRoundRect(0f, dp, w, h, rad, rad, p)
            p.color = letterC
            c.drawRoundRect(0f, 0f, w, h - dp, rad, rad, p)
            p.textSize = sp(24f)
            for ((i, s) in items.withIndex()) {
                val rowB = i / cols
                val colRaw = i % cols
                val col = if (rtl) cols - 1 - colRaw else colRaw
                val rowT = rows - 1 - rowB
                val rect = RectF(pad + col * cellW, pad + rowT * cellH, pad + (col + 1) * cellW, pad + (rowT + 1) * cellH)
                if (i == selected) {
                    p.color = 0xFF0A84FF.toInt()
                    c.drawRoundRect(rect.left + 2 * dp, rect.top + 2 * dp, rect.right - 2 * dp, rect.bottom - 2 * dp, 8 * dp, 8 * dp, p)
                    p.color = 0xFFFFFFFF.toInt()
                } else p.color = textC
                c.drawText(s, rect.centerX(), rect.centerY() - (p.descent() + p.ascent()) / 2, p)
            }
        }
    }

    private fun variantsFor(label: String): List<String> {
        val s = VARIANTS[label.lowercase()] ?: return emptyList()
        val list = s.map { it.toString() }.filter { !(numRow && label[0].isLetter() && it[0].isDigit()) }
        return if (shift) list.map { it.uppercase() } else list
    }

    private fun canLong(k: Key): Boolean = when (k.spec.token) {
        "SHIFT", "LANG", "E_SELECT" -> true
        "SPACE" -> langMode == 1
        "CH" -> hintsOn && k.spec.style == 0 && variantsFor(k.spec.label).isNotEmpty()
        else -> false
    }

    private fun startLong(k: Key) {
        when (k.spec.token) {
            "SHIFT" -> {
                shift = true; caps = true; longHandled = true
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                invalidate()
            }
            "E_SELECT" -> {
                longHandled = true
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                listener?.onEdit("SELALL", false)
            }
            "SPACE" -> {
                longHandled = true; pressed = null
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                invalidate()
                listener?.onPickIme()
            }
            "LANG" -> {
                longHandled = true; pressed = null
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                invalidate()
                listener?.onPickIme()
            }
            "CH" -> {
                val v = variantsFor(k.spec.label)
                if (v.isEmpty()) return
                showPopup(k, v)
                longHandled = true
            }
        }
    }

    private fun showPopup(k: Key, v: List<String>) {
        val rows = if (v.size > 4) 2 else 1
        val cols = (v.size + rows - 1) / rows
        val cw = 42 * dp
        val chh = 50 * dp
        val pad = 6 * dp
        val w = (cols * cw + 2 * pad).toInt()
        val h = (rows * chh + 2 * pad).toInt()
        val rtl = k.r.centerX() > width / 2f
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        var x = if (rtl) (loc[0] + k.r.centerX() + pad + cw / 2 - w).toInt()
        else (loc[0] + k.r.centerX() - pad - cw / 2).toInt()
        x = x.coerceIn(loc[0], maxOf(loc[0], loc[0] + width - w))
        val y = maxOf(0, (loc[1] + k.r.top - h - 6 * dp).toInt())
        val pv = VariantView(context, v, cols, rows, cw, chh, pad, rtl)
        val pw = PopupWindow(pv, w, h, false)
        pw.isTouchable = false
        pw.isClippingEnabled = false
        pw.showAtLocation(this, Gravity.NO_GRAVITY, x, y)
        popup = pw
        popupView = pv
        popupX = x
        popupY = y
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        updateSel(lastRawX, lastRawY, false)
        invalidate()
    }

    private fun updateSel(rawX: Float, rawY: Float, haptic: Boolean = true) {
        val pv = popupView ?: return
        val colRaw = ((rawX - popupX - pv.pad) / pv.cellW).toInt().coerceIn(0, pv.cols - 1)
        val col = if (pv.rtl) pv.cols - 1 - colRaw else colRaw
        val rowT = ((rawY - popupY - pv.pad) / pv.cellH).toInt().coerceIn(0, pv.rows - 1)
        val rowB = pv.rows - 1 - rowT
        val idx = (rowB * pv.cols + col).coerceAtMost(pv.items.size - 1)
        if (idx != pv.selected) {
            pv.selected = idx
            pv.invalidate()
            if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }

    private fun dismissPopup() {
        popup?.dismiss()
        popup = null
        popupView = null
    }

    // ---- touch ----

    private fun hit(x: Float, y: Float): Key? {
        val ex = hitEx
        val ey = rowGap * dp / 2
        return keys.firstOrNull {
            x >= it.r.left - ex && x <= it.r.right + ex && y >= it.r.top - ey && y <= it.r.bottom + ey
        }
    }

    private fun trackRaw(x: Float, y: Float) {
        getLocationOnScreen(loc)
        lastRawX = loc[0] + x
        lastRawY = loc[1] + y
    }

    private fun beginPress(x: Float, y: Float, id: Int) {
        handler.removeCallbacks(repeatTask)
        handler.removeCallbacks(longTask)
        repeated = false
        longHandled = false
        spaceSwiped = false
        activeId = id
        downX = x
        downY = y
        val k = hit(x, y)
        pressed = k
        if (k != null) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            click(k.spec.token)
            if (k.spec.token == "DEL") handler.postDelayed(repeatTask, 400)
            else if (canLong(k)) handler.postDelayed(longTask, longMs.toLong())
        }
        invalidate()
    }

    private fun endPress() {
        handler.removeCallbacks(repeatTask)
        handler.removeCallbacks(longTask)
        val k = pressed
        pressed = null
        val pv = popupView
        if (pv != null) {
            commit(pv.items[pv.selected])
            dismissPopup()
        } else if (k != null && !longHandled && !spaceSwiped) fire(k)
        longHandled = false
        repeated = false
        activeId = -1
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                trackRaw(e.x, e.y)
                beginPress(e.x, e.y, e.getPointerId(0))
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // second finger: finish the previous key at once so fast typing never drops a letter
                if (popupView != null) return true
                val idx = e.actionIndex
                val prev = pressed
                if (activeId != -1 && prev != null && !longHandled && !spaceSwiped) fire(prev)
                handler.removeCallbacks(repeatTask)
                handler.removeCallbacks(longTask)
                pressed = null
                trackRaw(e.getX(idx), e.getY(idx))
                beginPress(e.getX(idx), e.getY(idx), e.getPointerId(idx))
            }
            MotionEvent.ACTION_MOVE -> {
                val i = e.findPointerIndex(activeId)
                if (i < 0) return true
                val x = e.getX(i)
                val y = e.getY(i)
                trackRaw(x, y)
                if (popupView != null) {
                    updateSel(lastRawX, lastRawY)
                    return true
                }
                val pk = pressed
                if (pk != null && pk.spec.token == "SPACE" && langMode == 1) {
                    // swipe along the space bar switches the language
                    if (abs(x - downX) > 12 * dp) handler.removeCallbacks(longTask)
                    if (!spaceSwiped && abs(x - downX) > 48 * dp) {
                        spaceSwiped = true
                        lang = 1 - lang
                        symbols = false
                        clipMode = false
                        build()
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        invalidate()
                    }
                    return true
                }
                val k = hit(x, y)
                if (k !== pressed) {
                    // small finger drift keeps the key that was touched; only a real slide changes it
                    val dx = x - downX
                    val dy = y - downY
                    val far = dx * dx + dy * dy > (14 * dp) * (14 * dp)
                    if (pressed == null || far) beginPress(x, y, activeId)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (e.getPointerId(0) == activeId) endPress()
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (e.getPointerId(e.actionIndex) == activeId) endPress()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeatTask)
                handler.removeCallbacks(longTask)
                dismissPopup()
                pressed = null
                repeated = false
                longHandled = false
                activeId = -1
                invalidate()
            }
        }
        return true
    }

    private fun commit(s: String) {
        listener?.onText(s)
        if (shift && !caps) shift = false
    }

    private fun fire(k: Key) {
        val tk = k.spec.token
        when (tk) {
            "CH" -> commit(if (shift && k.spec.style == 0) k.spec.label.uppercase() else k.spec.label)
            "SPACE" -> listener?.onText(" ")
            "CUSTOM" -> listener?.onText(k.spec.label)
            "DEL" -> if (!repeated) listener?.onDelete()
            "ENTER" -> listener?.onEnter()
            "SHIFT" -> { if (shift) { shift = false; caps = false } else shift = true }
            "SYM" -> { symbols = true; clipMode = false; build() }
            "ABC" -> { symbols = false; emoji = false; clipMode = false; build() }
            "LANG" -> { lang = 1 - lang; symbols = false; clipMode = false; build() }
            "EMOJI" -> { emoji = true; clipMode = false; build() }
            "SUG" -> listener?.onSuggestion(k.spec.label)
            "CLIP" -> { listener?.onText(k.spec.label); clipMode = false; build() }
            "CLIPUP" -> { clipScroll = maxOf(0, clipScroll - 3); build() }
            "CLIPDN" -> { if (clipScroll + 3 < clips.size) clipScroll += 3; build() }
            "CLIPCLR" -> { ClipStore.clear(context); clips = emptyList(); clipScroll = 0; build() }
            "E_SELECT" -> selectMode = !selectMode
            "E_HIST", "P_CLIP" -> { clips = ClipStore.list(context); clipScroll = 0; clipMode = true; panelOpen = false; build() }
            "P_GRID" -> { panelOpen = !panelOpen; build() }
            "P_TR1", "P_TR2", "P_WAND" -> Toast.makeText(context, "Скоро", Toast.LENGTH_SHORT).show()
            "P_EMOJI" -> { emoji = true; clipMode = false; panelOpen = false; build() }
            "P_GEAR" -> { panelOpen = false; build(); listener?.onOpenSettings() }
            "E_SELALL" -> listener?.onEdit("SELALL", false)
            "E_CUT", "E_COPY", "E_PASTE" -> { listener?.onEdit(tk.removePrefix("E_"), false); selectMode = false }
            else -> if (tk.startsWith("E_")) listener?.onEdit(tk.removePrefix("E_"), selectMode)
        }
    }
}
