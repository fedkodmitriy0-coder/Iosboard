package com.example.iosboard

import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.textservice.SentenceSuggestionsInfo
import android.view.textservice.SpellCheckerSession
import android.view.textservice.SuggestionsInfo
import android.view.textservice.TextInfo
import android.view.textservice.TextServicesManager
import java.util.Locale
import kotlin.math.abs

class KeyboardService : InputMethodService(), KeyListener {
    private var view: KeyboardView? = null
    private var cm: ClipboardManager? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    // suggestions / autocorrect state
    private var session: SpellCheckerSession? = null
    private var sessionLang = ""
    private val pending = ArrayDeque<String>()
    private var currentWord = ""
    private var fix: String? = null
    private var fixFor = ""
    private var lastAuto: Triple<String, String, String>? = null // original, corrected, trailing char
    private var ignoreFix: String? = null
    private var allowSuggest = true
    private var reqWord = ""
    private var reqTime = 0L
    private val wordRe = Regex("[\\p{L}'’-]+$")

    private val spellListener = object : SpellCheckerSession.SpellCheckerSessionListener {
        override fun onGetSuggestions(results: Array<out SuggestionsInfo>?) {}

        override fun onGetSentenceSuggestions(results: Array<out SentenceSuggestionsInfo>?) {
            val word = pending.removeFirstOrNull() ?: return
            if (word != currentWord) return
            val r = results?.firstOrNull() ?: return
            if (r.suggestionsCount < 1) return
            val si = r.getSuggestionsInfoAt(0)
            val typo = (si.suggestionsAttributes and SuggestionsInfo.RESULT_ATTR_LOOKS_LIKE_TYPO) != 0
            val list = ArrayList<String>()
            for (i in 0 until minOf(si.suggestionsCount, 3)) {
                val sg = si.getSuggestionAt(i)
                if (!sg.isNullOrEmpty() && !sg.equals(word, true)) list.add(sg)
            }
            val shown = ArrayList<String>()
            shown.add(word)
            shown.addAll(list.take(2))
            view?.setSuggestions(shown)
            if (typo && list.isNotEmpty()) {
                val best = matchCase(word, list[0])
                if (closeEnough(word, best)) {
                    fix = best
                    fixFor = word
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        cm?.removePrimaryClipChangedListener(clipListener)
        try { session?.close() } catch (e: Exception) {}
        session = null
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val v = KeyboardView(this)
        v.listener = this
        view = v
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        view?.reloadPrefs()
        val t = info?.inputType ?: 0
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        val bad = v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_URI ||
            v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            v == InputType.TYPE_TEXT_VARIATION_FILTER ||
            (t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0
        allowSuggest = cls == InputType.TYPE_CLASS_TEXT && !bad
        lastAuto = null
        ignoreFix = null
        captureClip()
        refreshSuggestions()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        refreshSuggestions()
    }

    // ---------- clipboard ----------

    private fun captureClip() {
        if (!Prefs.clipHistory(this)) return
        try {
            val clip = cm?.primaryClip ?: return
            if (clip.itemCount == 0) return
            val extras = clip.description.extras
            if (extras != null && extras.getBoolean("android.content.extra.IS_SENSITIVE", false)) return
            val t = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
            ClipStore.add(this, t)
        } catch (e: Exception) {
        }
    }

    // ---------- suggestions / autocorrect ----------

    private fun wordAt(before: String): String = wordRe.find(before)?.value ?: ""

    private fun matchCase(word: String, sg: String): String = when {
        word.length > 1 && word.all { it.isUpperCase() } -> sg.uppercase()
        word[0].isUpperCase() -> sg.replaceFirstChar { it.uppercase() }
        else -> sg
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(
                    prev[j] + 1, cur[j - 1] + 1,
                    prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                )
            }
            prev = cur
        }
        return prev[b.length]
    }

    private fun closeEnough(a: String, b: String): Boolean =
        a.length >= 3 && abs(a.length - b.length) <= 2 &&
            lev(a.lowercase(), b.lowercase()) <= 2 &&
            !(a.drop(1).any { it.isUpperCase() } && !a.all { it.isUpperCase() })

    @Suppress("DEPRECATION")
    private fun ensureSession(lang: String): SpellCheckerSession? {
        if (session != null && sessionLang == lang) return session
        try { session?.close() } catch (e: Exception) {}
        session = null
        pending.clear()
        return try {
            val tsm = getSystemService(Context.TEXT_SERVICES_MANAGER_SERVICE) as TextServicesManager
            session = tsm.newSpellCheckerSession(null, Locale(lang), spellListener, false)
            sessionLang = lang
            session
        } catch (e: Exception) {
            null
        }
    }

    private fun refreshSuggestions() {
        val v = view ?: return
        if (!Prefs.suggest(this) || !allowSuggest) {
            currentWord = ""
            fix = null
            v.setSuggestions(emptyList())
            return
        }
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
        val word = wordAt(before)
        val now = SystemClock.uptimeMillis()
        if (word == reqWord && now - reqTime < 200 && word == currentWord) return
        if (word != currentWord) { fix = null; fixFor = "" }
        currentWord = word
        if (word.length < 2) {
            v.setSuggestions(emptyList())
            return
        }
        v.setSuggestions(listOf(word))
        val s = ensureSession(v.langCode()) ?: return
        reqWord = word
        reqTime = now
        try {
            if (pending.size > 8) pending.clear()
            pending.addLast(word)
            s.getSentenceSuggestions(arrayOf(TextInfo(word)), 3)
        } catch (e: Exception) {
        }
    }

    override fun onSuggestion(s: String) {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
        val word = wordAt(before)
        ic.beginBatchEdit()
        if (word.isNotEmpty()) ic.deleteSurroundingText(word.length, 0)
        ic.commitText("$s ", 1)
        ic.endBatchEdit()
        if (s == word) ignoreFix = word
        lastAuto = null
        refreshSuggestions()
    }

    // ---------- typing ----------

    override fun onText(s: String) {
        val ic = currentInputConnection ?: return
        if (s.length == 1 && (s[0] == ' ' || s[0] in ".,!?;:") &&
            Prefs.autocorrect(this) && Prefs.suggest(this) && allowSuggest
        ) {
            val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
            val word = wordAt(before)
            val f = fix
            if (f != null && word.isNotEmpty() && word == fixFor && word != ignoreFix) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(word.length, 0)
                ic.commitText(f + s, 1)
                ic.endBatchEdit()
                lastAuto = Triple(word, f, s)
                fix = null
                refreshSuggestions()
                return
            }
        }
        lastAuto = null
        ic.commitText(s, 1)
        refreshSuggestions()
    }

    override fun onDelete() {
        val ic = currentInputConnection ?: return
        val la = lastAuto
        if (la != null) {
            val before = ic.getTextBeforeCursor(la.second.length + la.third.length, 0)?.toString()
            if (before != null && before == la.second + la.third) {
                // Backspace right after an autocorrect puts the original word back
                ic.beginBatchEdit()
                ic.deleteSurroundingText(before.length, 0)
                ic.commitText(la.first, 1)
                ic.endBatchEdit()
                ignoreFix = la.first
                lastAuto = null
                refreshSuggestions()
                return
            }
        }
        lastAuto = null
        val sel = ic.getSelectedText(0)
        if (sel.isNullOrEmpty()) ic.deleteSurroundingTextInCodePoints(1, 0)
        else ic.commitText("", 1)
        refreshSuggestions()
    }

    override fun onPickIme() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    override fun onEdit(action: String, select: Boolean) {
        val ic = currentInputConnection ?: return
        lastAuto = null
        when (action) {
            "SELALL" -> ic.performContextMenuAction(android.R.id.selectAll)
            "CUT" -> ic.performContextMenuAction(android.R.id.cut)
            "COPY" -> ic.performContextMenuAction(android.R.id.copy)
            "PASTE" -> ic.performContextMenuAction(android.R.id.paste)
            else -> {
                val code = when (action) {
                    "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT
                    "RIGHT" -> KeyEvent.KEYCODE_DPAD_RIGHT
                    "UP" -> KeyEvent.KEYCODE_DPAD_UP
                    "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
                    "HOME" -> KeyEvent.KEYCODE_MOVE_HOME
                    "END" -> KeyEvent.KEYCODE_MOVE_END
                    else -> return
                }
                val meta = if (select) KeyEvent.META_SHIFT_ON else 0
                val t = SystemClock.uptimeMillis()
                ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
                ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
            }
        }
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        lastAuto = null
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        if ((opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
            action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        } else {
            ic.performEditorAction(action)
        }
    }
}
