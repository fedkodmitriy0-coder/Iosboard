package com.example.iosboard

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    private companion object {
        var savedScroll = 0
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val preview = KeyboardView(this)
        val edit = EditText(this)
        edit.hint = "Проверка клавиатуры"
        edit.inputType = InputType.TYPE_NULL
        edit.showSoftInputOnFocusCompat()
        preview.listener = object : KeyListener {
            override fun onText(s: String) {
                edit.text.insert(edit.selectionStart.coerceAtLeast(0), s)
            }
            override fun onDelete() {
                val st = edit.selectionStart
                if (st > 0) edit.text.delete(st - 1, st)
            }
            override fun onEnter() { edit.text.insert(edit.selectionStart.coerceAtLeast(0), "\n") }
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun button(t: String, a: () -> Unit) {
            val bt = Button(this); bt.text = t; bt.setOnClickListener { a() }; col.addView(bt)
        }
        button("1. Включить клавиатуру") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        button("2. Выбрать клавиатуру") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }

        fun slider(title: String, min: Int, max: Int, value: Int, key: String, unit: String, zero: String? = null) {
            fun txt(v: Int) = if (v == 0 && zero != null) "$title: $zero" else "$title: $v $unit"
            val label = TextView(this)
            label.text = txt(value)
            label.setPadding(0, pad, 0, 0)
            val sb = SeekBar(this)
            sb.max = max - min
            sb.progress = value - min
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    val v = p + min
                    label.text = txt(v)
                    Prefs.set(this@SettingsActivity, key, v)
                    preview.reloadPrefs()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(label); col.addView(sb)
        }
        slider("Скругление клавиш", 0, 23, Prefs.radius(this), "radius", "dp")
        slider("Отступ по бокам", 0, 32, Prefs.side(this), "side", "dp")
        slider("Отступ снизу", 0, 48, Prefs.bottom(this), "bottom", "dp")

        val sw = Switch(this)
        sw.text = "Меню символов при долгом нажатии"
        sw.isChecked = Prefs.hints(this)
        sw.setPadding(0, pad, 0, 0)
        sw.setOnCheckedChangeListener { _, on -> Prefs.set(this, "hints", on); preview.reloadPrefs() }
        col.addView(sw)
        slider("Время долгого нажатия", 150, 800, Prefs.longMs(this), "longMs", "мс")

        fun toggle(title: String, key: String, value: Boolean) {
            val s = Switch(this)
            s.text = title
            s.isChecked = value
            s.setPadding(0, pad, 0, 0)
            s.setOnCheckedChangeListener { _, on -> Prefs.set(this, key, on); preview.reloadPrefs() }
            col.addView(s)
        }
        toggle("Маленькие символы-подсказки в углу клавиш", "cornerHints", Prefs.cornerHints(this))
        toggle("Звук нажатий (как в системе)", "sound", Prefs.sound(this))
        toggle("Разные звуки для пробела, Backspace и Enter", "distinct", Prefs.distinct(this))
        slider("Громкость звука нажатий", 0, 100, Prefs.volume(this), "volume", "%", "как в системе")
        slider("Высота клавиш", 36, 64, Prefs.keyH(this), "keyH", "dp")
        slider("Ширина клавиш", 60, 100, Prefs.keyW(this), "keyW", "%")
        slider("Расстояние между клавишами", 0, 12, Prefs.gapX(this), "gapX", "dp", "0 (вплотную)")
        slider("Расстояние между рядами", 0, 20, Prefs.gapY(this), "gapY", "dp", "0 (вплотную)")
        slider("Ширина пузыря над буквой", 105, 220, Prefs.bubbleW(this), "bubbleW", "%")
        slider("Ширина Backspace", 100, 250, Prefs.delW(this), "delW", "%")
        toggle("Растягивать средний ряд до краёв", "stretch", Prefs.stretch(this))
        toggle("Ряд цифр сверху", "numRow", Prefs.numRow(this))
        toggle("Панель редактора (стрелки, копировать, вставить)", "editorBar", Prefs.editorBar(this))
        toggle("Панель из 4 квадратиков (буфер, эмодзи, настройки)", "panel", Prefs.panel(this))
        toggle("Подсказки слов (системная проверка орфографии)", "suggest", Prefs.suggest(this))
        toggle("Автоисправление при пробеле", "autocorrect", Prefs.autocorrect(this))
        toggle("Запоминать историю буфера обмена", "clipHistory", Prefs.clipHistory(this))
        button("Очистить историю буфера") {
            ClipStore.clear(this)
            Toast.makeText(this, "История буфера очищена", Toast.LENGTH_SHORT).show()
        }

        val symLabels = listOf("Нет", ",", ".", "?", "!", "@")
        val symValues = listOf("", ",", ".", "?", "!", "@")
        fun picker(title: String, key: String, current: String) {
            val t = TextView(this)
            t.text = title
            t.setPadding(0, pad, 0, 0)
            col.addView(t)
            val spn = Spinner(this)
            val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, symLabels)
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spn.adapter = ad
            spn.setSelection(symValues.indexOf(current).coerceAtLeast(0))
            spn.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    Prefs.setStr(this@SettingsActivity, key, symValues[pos])
                    preview.reloadPrefs()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            col.addView(spn)
        }
        picker("Символ слева от пробела", "symL", Prefs.symL(this))
        picker("Символ справа от пробела", "symR", Prefs.symR(this))
        toggle("Показывать ряд своих клавиш", "customOn", Prefs.customOn(this))
        val ct = TextView(this)
        ct.text = "Свои клавиши (через пробел, до 12 штук)"
        ct.setPadding(0, pad, 0, 0)
        col.addView(ct)
        val ce = EditText(this)
        ce.hint = "Например: @ # _ ~ :) @gmail.com"
        ce.setText(Prefs.custom(this))
        ce.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                Prefs.setStr(this@SettingsActivity, "custom", s?.toString() ?: "")
                preview.reloadPrefs()
            }
        })
        col.addView(ce)

        fun radios(title: String, items: List<String>, selected: Int, onPick: (Int) -> Unit): RadioGroup {
            val t = TextView(this); t.text = title; t.setPadding(0, pad, 0, 0); col.addView(t)
            val g = RadioGroup(this)
            items.forEachIndexed { i, s ->
                val r = RadioButton(this); r.text = s; r.id = i + 1000; g.addView(r)
            }
            g.check(selected + 1000)
            g.setOnCheckedChangeListener { _, id -> onPick(id - 1000) }
            col.addView(g)
            return g
        }
        radios("Кнопка эмодзи", listOf("Под клавиатурой (как на iPhone)", "В нижней строке клавиатуры (как на Android)", "Убрать из клавиатуры (будет в панели)"),
            Prefs.emojiPos(this)) {
            Prefs.set(this, "emojiPos", it); preview.reloadPrefs()
        }
        radios("Смена языка", listOf("Кнопка с глобусом", "Свайп по пробелу (вправо или влево)"), Prefs.langMode(this)) {
            Prefs.set(this, "langMode", it); preview.reloadPrefs()
        }
        var themeChanged: () -> Unit = {}
        val themeGroup = radios("Тема", listOf("Как в системе", "Светлая", "Тёмная", "Серая", "Своя"), Prefs.theme(this)) {
            Prefs.set(this, "theme", it); preview.reloadPrefs(); themeChanged()
        }

        // ---- own theme: colours of keyboard parts and of the app ----
        val sysDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        fun effective(): IntArray =
            if (Prefs.theme(this) == 4) Prefs.customColors(this) else Palette.builtIn(Prefs.theme(this), sysDark)
        val swatches = ArrayList<Pair<View, Int>>()
        fun paintSwatch(v: View, c: Int) {
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(c)
            d.setStroke((2 * dp).toInt(), 0x66888888)
            v.background = d
        }
        fun refreshSwatches() {
            val e = effective()
            for ((v, i) in swatches) {
                val acc = Prefs.accent(this)
                paintSwatch(v, if (i == -2) Prefs.bubble(this).let { if (it == 0) e[1] else it } else if (i < 0) (if (acc == 0) 0xFF6750A4.toInt() else acc) else e[i])
            }
        }
        themeChanged = { refreshSwatches() }
        fun ensureCustom() {
            if (Prefs.theme(this) != 4) {
                Prefs.setCustom(this, effective())
                Prefs.set(this, "theme", 4)
                themeGroup.check(4 + 1000)
            }
        }
        lateinit var scrollRef: ScrollView
        fun colorRow(title: String, idx: Int) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, (10 * dp).toInt(), 0, (10 * dp).toInt())
            val tv = TextView(this)
            tv.text = title
            tv.textSize = 16f
            row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
            val sv = View(this)
            row.addView(sv, LinearLayout.LayoutParams((32 * dp).toInt(), (32 * dp).toInt()))
            swatches.add(Pair(sv, idx))
            row.setOnClickListener {
                val cur = if (idx == -2) Prefs.bubble(this).let { if (it == 0) effective()[1] else it } else if (idx < 0) Prefs.accent(this) else effective()[idx]
                ColorPicker(this, title, if (cur == 0) 0xFF6750A4.toInt() else cur, true) { res ->
                    if (idx == -2) {
                        Prefs.set(this, "cBubble", res ?: 0)
                        preview.reloadPrefs()
                        refreshSwatches()
                    } else if (idx < 0) {
                        Prefs.set(this, "cAccent", res ?: 0)
                        savedScroll = scrollRef.scrollY
                        recreate()
                    } else {
                        ensureCustom()
                        val pal = Prefs.customColors(this)
                        pal[idx] = res ?: Palette.builtIn(1, false)[idx]
                        Prefs.setCustom(this, pal)
                        preview.reloadPrefs()
                        refreshSwatches()
                    }
                }.show()
            }
            col.addView(row)
        }
        val hdr = TextView(this)
        hdr.text = "Своя тема и цвета"
        hdr.textSize = 18f
        hdr.setPadding(0, pad, 0, 0)
        col.addView(hdr)
        button("Создать свою тему на основе текущей") {
            Prefs.setCustom(this, effective())
            Prefs.set(this, "theme", 4)
            themeGroup.check(4 + 1000)
            refreshSwatches()
        }
        button("Своя тема с нуля (чистая палитра)") {
            Prefs.setCustom(this, Palette.builtIn(1, false))
            Prefs.set(this, "theme", 4)
            themeGroup.check(4 + 1000)
            refreshSwatches()
        }
        colorRow("Фон клавиатуры", 0)
        colorRow("Обычные клавиши (буквы, цифры, запятая, точка)", 1)
        colorRow("Пробел", 2)
        colorRow("Особые клавиши (123, Shift, Enter, Backspace)", 3)
        colorRow("Цвет текста на клавишах", 4)
        colorRow("Цвет пузыря и нажатой клавиши", -2)
        colorRow("Цвет приложения", -1)
        refreshSwatches()

        val scroll = ScrollView(this)
        scrollRef = scroll
        scroll.addView(col)
        scroll.post { scroll.scrollTo(0, savedScroll); savedScroll = 0 }
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(edit, LinearLayout.LayoutParams(-1, -2))
        root.addView(preview, LinearLayout.LayoutParams(-1, -2))
        val accent = Prefs.accent(this)
        if (accent != 0) {
            applyAccent(col, accent)
            actionBar?.setBackgroundDrawable(ColorDrawable(accent))
            window.statusBarColor = accent
        }
        setContentView(root)
    }

    private fun lum(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    private fun applyAccent(v: View, accent: Int) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val onOff = ColorStateList(states, intArrayOf(accent, 0xFF9E9E9E.toInt()))
        val solid = ColorStateList.valueOf(accent)
        val track = ColorStateList(
            states,
            intArrayOf(Color.argb(110, Color.red(accent), Color.green(accent), Color.blue(accent)), 0x559E9E9E)
        )
        val fg = if (lum(accent) > 0.6f) Color.BLACK else Color.WHITE
        when (v) {
            is SeekBar -> { v.progressTintList = solid; v.thumbTintList = solid }
            is Switch -> { v.thumbTintList = onOff; v.trackTintList = track }
            is RadioButton -> v.buttonTintList = onOff
            is Button -> { v.backgroundTintList = solid; v.setTextColor(fg) }
            is ViewGroup -> for (i in 0 until v.childCount) applyAccent(v.getChildAt(i), accent)
        }
    }

    private fun EditText.showSoftInputOnFocusCompat() {
        showSoftInputOnFocus = false
    }
}
